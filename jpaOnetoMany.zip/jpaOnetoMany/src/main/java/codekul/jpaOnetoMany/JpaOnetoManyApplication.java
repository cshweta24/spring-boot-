package codekul.jpaOnetoMany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaOnetoManyApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaOnetoManyApplication.class, args);
	}

}
